print("Mursal Ahmadi") # Displaying my name
print(19) #Displaying my age
print("I love coding") #Displaying my interest





#Snake-Case type in String
my_full_name = "Mursal Ahmadi"
print(my_full_name)
#camelCase Type in string
friendName = "Samira"
print(friendName)
#PascalCase type in string
ClassName= "Python Programming Language"
print(ClassName)

 #Snake_Case Type in Integers
my_age = 20
print(my_age)
#camelCase Type in Integers
myHeigth = 60 
print(myHeigth)
#PascalCase Type in Integers
StartClassTime = 9
print(StartClassTime)
  
#Snake_Case Type in Float
my_weight = 50.2
print(my_weight)
#camelCase Type in Float
friendHeigth = 60.13
print(friendHeigth)
#PascalCase Type in Float
MyScore = 90.50
print(MyScore)



