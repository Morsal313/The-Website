# #Arithmathic  Operators
# num1 = int(input("Please Enter a Number; "))
# num2=int(input("Please Enter Seconf Number: "))
# print(" The Addition of it is: ", num1 + num2)
# print(" The Subtraction of it is: ", num1 - num2)
# print(" The Mutiplication  of it is: " , num1 * num2)
# print(" The Division of it is: " , num1 / num2)
# print("Exponentiation of it is: " , num1  ** num2)
# print("The floor Division is: " , num1 // num2)
# print("The Modulus of these numbers are: " , num1 % num2)

# #Assignment Operators
# a = 12
# b = 91
# print(a == b)
# print(a != b)
# print(a > b)
# print(a < b)
# print(a>= b)
# print(a <= b)

# #Logical Opertors
# First_number = 100
# SecondNumber= 84
# print(First_number > 199 and SecondNumber == 100)
# print(First_number != 100 or SecondNumber >= 90 )
# print(not( First_number == SecondNumber))






#Conditional Statement
# num=int(input("Please enter a number: ")) #we ask user for an input which is integer.
# if num > 0: # here if user enters a number is greater than zero
#     print("The number is greater than zero") # it prints that the number is greater than zero statement.
# elif num < 0: # it checks if the input user is less than zero.
#     print("The number is less than zero") #it would print that the number is less than zero statement.
# else:
#     print("The number is equal to zero.")# and else statement prints if the none is ok.


#For loop 
for i in range(1,101): # in this line, we assign 1 up to 100 to i by using for loop.
    print(i) #it prints 1 to 100

#While loop
i=1
while i <=100:# when i is smaller than 100 or equal to
    print(i) #it prints  i
    i += 1 #and i increases by 1 up to 100.
