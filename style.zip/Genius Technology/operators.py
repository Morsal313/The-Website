a = 20
b= 10
print("The addition of a and b is:" a +b) 

